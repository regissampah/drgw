(function() {
  if (window.__geoscanner_hooked) return;
  window.__geoscanner_hooked = true;

  function broadcastCoords(coords) {
    if (!coords || typeof coords.lat !== 'number' || typeof coords.lng !== 'number') return;
    window.postMessage({ source: "GEOSCANNER_CORE", type: "COORDINATES_FOUND", coords }, "*");
  }

  // Intercept XHR
  const rawOpen = XMLHttpRequest.prototype.open;
  const rawSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...args) {
    this._url = url;
    return rawOpen.call(this, method, url, ...args);
  };

  XMLHttpRequest.prototype.send = function(...args) {
    this.addEventListener("readystatechange", function() {
      if (this.readyState === 4 && this.status === 200 && this._url) {
        try {
          if (this._url.includes("google") || this._url.includes("game") || this._url.includes("round")) {
            extractCoordsFromText(this.responseText);
          }
        } catch (e) {}
      }
    });
    return rawSend.apply(this, args);
  };

  // Intercept Fetch
  const rawFetch = window.fetch;
  window.fetch = async function(...args) {
    const response = await rawFetch.apply(this, args);
    const url = args[0] instanceof Request ? args[0].url : String(args[0] || "");
    if (url.includes("google") || url.includes("game") || url.includes("round")) {
      response.clone().text().then(text => extractCoordsFromText(text)).catch(() => {});
    }
    return response;
  };

  function extractCoordsFromText(text) {
    if (!text || text.length < 10) return;
    try {
      const data = JSON.parse(text);
      const patterns = [
        () => [data[1][0][5][0][1][0][2], data[1][0][5][0][1][0][3]],
        () => [data[1][5][0][1][0][2], data[1][5][0][1][0][3]],
        () => [data[0][5][0][1][0][2], data[0][5][0][1][0][3]]
      ];
      for (const p of patterns) {
        try {
          const [lat, lng] = p();
          if (isValid(lat, lng)) { broadcastCoords({ lat, lng }); return; }
        } catch (e) {}
      }
    } catch (e) {
      const match = text.match(/!2d([\-\d.]+)!3d([\-\d.]+)/);
      if (match) {
        const lng = parseFloat(match[1]), lat = parseFloat(match[2]);
        if (isValid(lat, lng)) broadcastCoords({ lat, lng });
      }
    }
  }

  function isValid(lat, lng) {
    return typeof lat === 'number' && typeof lng === 'number' && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180 && (lat !== 0 || lng !== 0);
  }
})();
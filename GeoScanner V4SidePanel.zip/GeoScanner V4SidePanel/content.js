try {
  const s = document.createElement('script');
  s.src = chrome.runtime.getURL('injected_hook.js');
  s.onload = () => s.remove();
  (document.head || document.documentElement).appendChild(s);
} catch (e) {}

window.addEventListener('message', (event) => {
  if (event.data?.source === 'GEOSCANNER_CORE' && event.data?.type === 'COORDINATES_FOUND') {
    const coords = event.data.coords;
    chrome.storage.local.set({
      geoscanner_live_coords: coords,
      geoscanner_coords_time: Date.now()
    });

    chrome.runtime.sendMessage({
      action: "ui_update_coords",
      coordinates: coords
    }).catch(() => {});
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getCoordinates") {
    chrome.storage.local.get(['geoscanner_live_coords'], (data) => {
      if (data.geoscanner_live_coords) {
        sendResponse({ success: true, coordinates: data.geoscanner_live_coords });
      } else {
        sendResponse({ success: false, error: "Koordinat belum terdeteksi." });
      }
    });
    return true;
  }
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "take-screenshot") {
    captureAndSend();
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "capture_screen") {
    captureAndSend()
      .then((dataUrl) => sendResponse({ status: "success", dataUrl }))
      .catch((err) => sendResponse({ status: "error", message: err.message }));
    return true;
  }
});

async function captureAndSend() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) throw new Error("Tidak ada tab aktif.");

  return new Promise((resolve, reject) => {
    chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        chrome.runtime.sendMessage({
          action: "screenshot_captured",
          dataUrl: dataUrl
        });
        resolve(dataUrl);
      }
    });
  });
}
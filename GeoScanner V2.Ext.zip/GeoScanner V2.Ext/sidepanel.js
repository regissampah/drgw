const PUBLIC_CSV_URL = "https://docs.google.com/spreadsheets/d/e/2PACX-1vRo73KtbjL9lD4iLDSTIdj6ZYZMe0Du_TciZSjucxCrzy_uHN4KYTV_MeOcLsexOtsqpIRwOJIYDtAc/pub?gid=0&single=true&output=csv";
const MODEL_NAME = "gemini-2.5-flash";

// Kode Akses Utama
const PASS_CODE = "GSV4";

let mapInstance = null;
let lastRenderedLat = null;
let lastRenderedLng = null;
let base64Image = null;

// Custom Marker Leaflet
const customPinIcon = window.L ? L.divIcon({
  className: 'custom-leaflet-pin',
  html: `<div style="width:24px;height:24px;background:#7c4dff;border:3px solid #fff;border-radius:50%;box-shadow:0 0 10px rgba(124,77,255,0.8);position:relative;">
          <div style="width:8px;height:8px;background:#92e350;border-radius:50%;position:absolute;top:5px;left:5px;"></div>
        </div>`,
  iconSize: [24, 24],
  iconAnchor: [12, 12]
}) : null;

// Logika Verifikasi Akses
async function checkAccessAuth() {
  const data = await chrome.storage.local.get('geoscanner_auth');
  const lockOverlay = document.getElementById('access-lock-overlay');
  
  if (data.geoscanner_auth === true) {
    lockOverlay?.classList.add('hidden');
  } else {
    lockOverlay?.classList.remove('hidden');
  }
}

function processLogin() {
  const inputEl = document.getElementById('access-code-input');
  const errorEl = document.getElementById('access-error-msg');
  const inputCode = inputEl ? inputEl.value.trim().toUpperCase() : "";

  if (inputCode === PASS_CODE) {
    chrome.storage.local.set({ 'geoscanner_auth': true }, () => {
      document.getElementById('access-lock-overlay')?.classList.add('hidden');
      if (errorEl) errorEl.style.display = 'none';
      if (inputEl) inputEl.value = "";
    });
  } else {
    if (errorEl) {
      errorEl.textContent = "Kode akses salah!";
      errorEl.style.display = 'block';
    }
  }
}

document.getElementById('verify-access-btn')?.addEventListener('click', processLogin);
document.getElementById('access-code-input')?.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') processLogin();
});

// Reverse Geocoding
async function fetchReverseGeocode(lat, lng) {
  const countryEl = document.getElementById('info-country-val');
  const cityEl = document.getElementById('info-city-val');
  
  if (countryEl) countryEl.textContent = "Memuat...";
  if (cityEl) cityEl.textContent = "Memuat...";

  try {
    const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`);
    if (!res.ok) throw new Error("Gagal mengambil lokasi");
    const data = await res.json();
    
    const country = data.address?.country || "Tidak Diketahui";
    const city = data.address?.city || data.address?.town || data.address?.state || data.address?.region || "Tidak Diketahui";

    if (countryEl) countryEl.textContent = country;
    if (cityEl) cityEl.textContent = city;
  } catch (err) {
    if (countryEl) countryEl.textContent = "Terdeteksi";
    if (cityEl) cityEl.textContent = "Terdeteksi";
  }
}

// Storage Helpers
async function getStoredApiKey() {
  const data = await chrome.storage.local.get('geoscanner_api_key');
  return data.geoscanner_api_key || "";
}

async function setStoredApiKey(key) {
  if (!key) await chrome.storage.local.remove('geoscanner_api_key');
  else await chrome.storage.local.set({ 'geoscanner_api_key': key });
}

async function updateHeaderApiIndicator() {
  const key = await getStoredApiKey();
  const icon = document.getElementById('api-status-icon');
  if (icon) {
    icon.className = key ? 'status-active' : 'status-inactive';
  }
}

// Control Modal
function showModal(id) {
  document.getElementById(id)?.classList.remove('hidden');
}

function hideModal(id) {
  document.getElementById(id)?.classList.add('hidden');
}

function showMessage(title, desc) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-desc').innerHTML = desc;
  showModal('message-modal');
}

// Modals Handlers
document.getElementById('open-api-btn').onclick = async () => {
  const key = await getStoredApiKey();
  document.getElementById('api-key-input').value = key;
  showModal('api-modal');
};

document.getElementById('close-api-btn').onclick = () => hideModal('api-modal');
document.getElementById('close-msg-btn').onclick = () => hideModal('message-modal');
document.getElementById('close-pool-btn').onclick = () => hideModal('shared-pool-modal');

document.getElementById('open-pool-btn').onclick = () => {
  hideModal('api-modal');
  showModal('shared-pool-modal');
  fetchPoolData();
};

document.getElementById('toggle-show-key').onclick = () => {
  const input = document.getElementById('api-key-input');
  input.type = input.type === 'password' ? 'text' : 'password';
};

document.getElementById('clear-api-key').onclick = () => {
  document.getElementById('api-key-input').value = '';
};

document.getElementById('save-api-btn').onclick = async () => {
  const val = document.getElementById('api-key-input').value.trim();
  await setStoredApiKey(val);
  await updateHeaderApiIndicator();
  hideModal('api-modal');
};

// CSV Pool Loader
async function fetchPoolData() {
  const container = document.getElementById('pool-list-container');
  if (!container) return;

  container.innerHTML = '<tr><td colspan="3" style="text-align: center; padding: 12px; color: var(--text-muted);">Memuat data...</td></tr>';

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    const response = await fetch(`${PUBLIC_CSV_URL}&t=${Date.now()}`, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
    const csvText = await response.text();

    const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length <= 1) {
      container.innerHTML = '<tr><td colspan="3" style="text-align: center; padding: 12px; color: var(--text-muted);">Sheet kosong.</td></tr>';
      return;
    }

    const delimiter = lines[0].includes(';') ? ';' : ',';
    const items = lines.slice(1).map(line => {
      const rawCols = line.split(delimiter);
      if (rawCols.length < 2) return null;
      const clean = (val) => val ? val.replace(/^"|"$/g, '').trim() : '';
      return {
        provider: clean(rawCols[0]),
        key: clean(rawCols[1]),
        status: rawCols[2] ? clean(rawCols[2]) : 'Active'
      };
    }).filter(item => item !== null && item.key.length > 5);

    if (items.length === 0) {
      container.innerHTML = '<tr><td colspan="3" style="text-align: center; padding: 12px; color: var(--text-muted);">Tidak ada baris data valid.</td></tr>';
      return;
    }

    container.innerHTML = items.map((item) => {
      const isActive = item.status.toLowerCase() === 'active';
      return `
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
          <td style="padding: 6px 4px; font-weight: 700;">${item.provider}</td>
          <td style="padding: 6px 4px;"><span class="${isActive ? 'status-active' : 'status-inactive'}">${item.status}</span></td>
          <td style="padding: 6px 4px; text-align: right;">
            ${isActive ? `<button data-key="${item.key}" data-provider="${item.provider}" class="use-key-btn btn btn-purple" style="padding: 2px 8px; font-size: 9px; width: auto; display: inline-flex;">Gunakan</button>` : '<span style="color: var(--text-muted); font-size: 9px;">OFF</span>'}
          </td>
        </tr>
      `;
    }).join('');

    document.querySelectorAll('.use-key-btn').forEach(btn => {
      btn.onclick = async (e) => {
        const key = e.target.getAttribute('data-key');
        const provider = e.target.getAttribute('data-provider');
        await setStoredApiKey(key);
        await updateHeaderApiIndicator();
        hideModal('shared-pool-modal');
        showMessage('Berhasil', `Menggunakan API Key dari <b>${provider}</b>.`);
      };
    });
  } catch (error) {
    container.innerHTML = `<tr><td colspan="3" style="text-align: center; padding: 12px; color: var(--accent-red); font-size: 10px;">${error.message}</td></tr>`;
  }
}

// Map Rendering (Fixed Issue Reset & Invalidate Size)
async function checkAndRenderLiveCoords() {
  const data = await chrome.storage.local.get(['geoscanner_live_coords', 'geoscanner_coords_time']);
  if (data.geoscanner_live_coords && (Date.now() - (data.geoscanner_coords_time || 0) < 180000)) {
    const { lat, lng } = data.geoscanner_live_coords;
    if (lat !== lastRenderedLat || lng !== lastRenderedLng) {
      lastRenderedLat = lat;
      lastRenderedLng = lng;
      renderMap(lat, lng);
    }
  }
}

function renderMap(lat, lng) {
  const card = document.getElementById('live-map-card');
  const text = document.getElementById('detection-mode-text');
  const coordsVal = document.getElementById('info-coords-val');
  const gmapsLink = document.getElementById('gmaps-link');

  if (card) card.classList.remove('hidden');
  if (text) { text.textContent = "KOORDINAT TERDETEKSI"; text.className = "status-active"; }
  if (coordsVal) coordsVal.textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  if (gmapsLink) gmapsLink.href = `https://www.google.com/maps?q=${lat},${lng}`;

  fetchReverseGeocode(lat, lng);

  if (window.L) {
    // 1. Reset instance map lama secara komplit
    if (mapInstance) {
      mapInstance.off();
      mapInstance.remove();
      mapInstance = null;
    }

    // 2. Bersihkan DOM container map dari sisa Leaflet lama
    const mapContainer = document.getElementById('map');
    if (mapContainer) {
      mapContainer.innerHTML = '';
    }

    // 3. Re-inisialisasi map baru
    mapInstance = L.map('map').setView([lat, lng], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(mapInstance);
    L.marker([lat, lng], { icon: customPinIcon }).addTo(mapInstance);

    // 4. Invalidate size untuk memastikan rendering tile sempurna
    setTimeout(() => {
      if (mapInstance) {
        mapInstance.invalidateSize();
      }
    }, 150);
  }
}

// Cek Lokasi Manual
document.getElementById('auto-fetch-btn').onclick = async () => {
  const btn = document.getElementById('auto-fetch-btn');
  btn.textContent = "Memindai...";

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]?.id) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "getCoordinates" }, (response) => {
        if (response?.success && response?.coordinates) {
          renderMap(response.coordinates.lat, response.coordinates.lng);
        }
      });
    }
  });

  const data = await chrome.storage.local.get(['geoscanner_live_coords']);
  if (data.geoscanner_live_coords) {
    renderMap(data.geoscanner_live_coords.lat, data.geoscanner_live_coords.lng);
    btn.textContent = "📡 Cek Lokasi";
  } else {
    setTimeout(() => {
      btn.textContent = "📡 Cek Lokasi";
      showMessage("Lokasi Belum Ditemukan", "Pastikan Anda berada di ronde permainan GeoGuessr / OpenGuessr dan coba tekan F5.");
    }, 800);
  }
};

// Screenshot Handler
document.getElementById('screenshot-button').onclick = () => {
  chrome.runtime.sendMessage({ action: "capture_screen" });
};

document.getElementById('reset-preview-btn').onclick = () => {
  base64Image = null;
  document.getElementById('ai-preview-container').classList.add('hidden');
  document.getElementById('results-section').classList.add('hidden');
};

// Realtime Listener
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "ui_update_coords" && msg.coordinates) {
    renderMap(msg.coordinates.lat, msg.coordinates.lng);
  }
  if (msg.action === "screenshot_captured" && msg.dataUrl) {
    base64Image = msg.dataUrl.split(',')[1];
    document.getElementById('image-preview').src = msg.dataUrl;
    document.getElementById('ai-preview-container').classList.remove('hidden');
    document.getElementById('results-section').classList.add('hidden');
  }
});

// Gemini AI Analysis
document.getElementById('analyze-button').onclick = async () => {
  const key = await getStoredApiKey();
  if (!key) {
    showModal('api-modal');
    return;
  }

  const btn = document.getElementById('analyze-button');
  btn.disabled = true;
  btn.textContent = "Menganalisis...";

  try {
    const prompt = `Analyze this image for geographical location identification (GeoGuessr style).
Return ONLY a valid JSON object matching this schema:
{
  "negara": "Country name",
  "kota": "City or region name",
  "bahasa": "Primary language detected or used in area",
  "koordinat": {"lat": 0.0, "lng": 0.0}
}
Use Indonesian for text values.`;

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL_NAME}:generateContent?key=${key}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }, { inlineData: { mimeType: "image/jpeg", data: base64Image } }] }],
        generationConfig: { responseMimeType: "application/json" }
      })
    });

    if (!response.ok) throw new Error("Gagal menghubungi Gemini API");

    const data = await response.json();
    const resultJson = JSON.parse(data.candidates[0].content.parts[0].text);
    
    document.getElementById('results-section').classList.remove('hidden');
    document.getElementById('result-content').innerHTML = `
      <div style="text-align: center; margin-bottom: 8px;">
        <strong style="font-size: 14px; color: #fff;">${resultJson.negara || 'Terdeteksi'}</strong>
        <div style="color: var(--accent-purple); font-weight: 700; font-size: 10px;">${resultJson.kota || ''}</div>
      </div>
      <div style="font-size: 11px;">
        <div><b>Bahasa:</b> ${resultJson.bahasa || '-'}</div>
        <div><b>Koordinat:</b> ${resultJson.koordinat ? `${resultJson.koordinat.lat}, ${resultJson.koordinat.lng}` : '-'}</div>
      </div>
    `;
  } catch (e) {
    showMessage('Gagal Analisis', e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "Analisis Visual Gemini AI";
  }
};

// Init awal
checkAccessAuth();
updateHeaderApiIndicator();
checkAndRenderLiveCoords();